package com.example.assignment2;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
// --------------------------------------------------------------------
// Assignment 2
// Written by: Viktor Kostadinov
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
// recycler adapter for cart
public class CartRecyclerAdapter extends RecyclerView.Adapter<CartRecyclerAdapter.ViewHolder> {
    boolean neededStockChanged = false;// cartview

    private final ListenerInterface listener;
    Context cartContext;
    ArrayList<GiftInCart> cartList;

    public CartRecyclerAdapter(Context giftContext, ArrayList<GiftInCart> cartList, ListenerInterface listener) {
        this.cartContext = giftContext;
        this.cartList = cartList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CartRecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cartview, parent, false);
        return new ViewHolder(view, listener);
    }

    @Override
    public void onBindViewHolder(@NonNull CartRecyclerAdapter.ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        GiftInCart gift = cartList.get(position);
        gift.setNeededStock(gift.getNeededStock());
        //gift.setTotalPrice(Double.toString((Double.parseDouble(gift.getPrice())) * Double.parseDouble(gift.getNeededStock())));
        holder.giftName.setText(String.valueOf(gift.getName()));
        //  holder.giftPrice.setText(String.valueOf(gift.getPrice()));
        holder.giftPrice.setText(String.valueOf(gift.getTotalPrice()));
        holder.giftAvailableStock.setText(String.valueOf(gift.getAvailableStock()));
        holder.giftNeededStock.setText(String.valueOf(gift.getNeededStock()));
        holder.giftPrice.append("$");
        holder.giftAvailableStock.append(" In Stock.");
        Glide.with(cartContext).load(gift.getImageUrl()).into(holder.giftImage);
        String loggedInUserID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        holder.removeGift.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String loggedUserID = FirebaseAuth.getInstance().getCurrentUser().getUid();
                DatabaseReference cartDBRef = FirebaseDatabase.getInstance().getReference().child("Cart" + loggedUserID);
                //DatabaseReference giftIdRef = cartDBRef.child("gift_id");
                cartDBRef.child(gift.getGift_id()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                         if (task.isSuccessful()) {
                            cartList.remove(position);
                            notifyDataSetChanged();


                         }
                    }
                });

            }
        });
        //gift.setNeededStock("2");
        //insertGiftIntoCart(gift, loggedInUserID);


    }

    private void insertGiftIntoCart(GiftInCart gift, String loggedUserID) {
        DatabaseReference cartDBRef = FirebaseDatabase.getInstance().getReference().child("Cart" + loggedUserID);
        DatabaseReference giftIdRef = cartDBRef.child("gift_id");
        giftIdRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()) {
                    cartDBRef.child(gift.getGift_id()).setValue(gift);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

    }

    @Override
    public int getItemCount() {
        return cartList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView giftName;
        TextView giftPrice;
        ImageView giftImage;
        TextView giftAvailableStock;
        EditText giftNeededStock;
        Button removeGift;

        public ViewHolder(@NonNull View itemView, ListenerInterface listener) {
            super(itemView);
            giftImage = itemView.findViewById(R.id.cartImageListView);
            giftName = itemView.findViewById(R.id.cartGiftName);
            giftPrice = itemView.findViewById(R.id.cartGiftPrice);
            giftAvailableStock = itemView.findViewById(R.id.cartInStock);
            giftNeededStock = itemView.findViewById(R.id.cartDesiredStock);
            removeGift = itemView.findViewById(R.id.removeButton);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });

        }
    }
}






