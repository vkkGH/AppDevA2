package com.example.assignment2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
// --------------------------------------------------------------------
// Assignment 2
// Written by: Viktor Kostadinov
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------

// made a cart for fun, this is the recycler, it has more or less of the features I want but is incomplete for now (maybe do it another time)
// it calculates total price, you can update, remove gifts... the only thing missing is being able to update quantity in cart and update that in the database and update the prices
public class CartRecycler extends AppCompatActivity implements ListenerInterface {           // cart

    RecyclerView recyclerView;
    private DatabaseReference database;
    private ArrayList<GiftInCart> cartList;
    private CartRecyclerAdapter cartRecyclerAdapter;
    String loggedInUserID = FirebaseAuth.getInstance().getCurrentUser().getUid();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cart);
        getSupportActionBar().hide();
        BottomNavigationView navigationMenu = findViewById(R.id.cartNavigationMenu);
        navigationMenu.getMenu().findItem(R.id.cart).setChecked(true);
        navigationMenu.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.favorites:
                        Intent intent = new Intent(CartRecycler.this, FavoritesRecycler.class);
                        overridePendingTransition(0, 0);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        break;
                    case R.id.shop:
                        intent = new Intent(CartRecycler.this, ShopRecycler.class);
                        overridePendingTransition(0, 0);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        break;
                    case R.id.profile:
                        intent = new Intent(CartRecycler.this, MyProfile.class);
                        overridePendingTransition(0, 0);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        break;
                    case R.id.cart:
                        intent = new Intent(CartRecycler.this, CartRecycler.class);
                        overridePendingTransition(0, 0);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        break;



                }
                return true;
            }
        }); {

        }
        Button orderNowButton = findViewById(R.id.orderButton);
        orderNowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CartRecycler.this, PayRecycler.class);
                overridePendingTransition(0, 0);
                intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
            }
        });
        recyclerView = findViewById(R.id.cartGifts);
       // loggedInUserID
        database = FirebaseDatabase.getInstance().getReference("Cart" + loggedInUserID);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        cartList = new ArrayList<>();
        cartRecyclerAdapter = new CartRecyclerAdapter(this, cartList, this);
        recyclerView.setAdapter(cartRecyclerAdapter);
        TextView getTotalPrice = findViewById(R.id.cartPriceView);
        FirebaseDatabase.getInstance().getReference().child("Cart" + loggedInUserID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                Double totalPriceInCart = 0.00;
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    GiftInCart gift = dataSnapshot.getValue(GiftInCart.class);
                    String totalPriceInCartToString;
                    totalPriceInCart += Double.parseDouble(gift.getTotalPrice());
                    totalPriceInCartToString = Double.toString(totalPriceInCart);
                    getTotalPrice.setText(totalPriceInCartToString);
                    getTotalPrice.append(" $");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    GiftInCart gift = dataSnapshot.getValue(GiftInCart.class);
                    cartList.add(gift);

                }
                cartRecyclerAdapter.notifyDataSetChanged();


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }


    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(CartRecycler.this, GiftView.class);
        intent.putExtra("Image", cartList.get(position).getImageUrl());
        intent.putExtra("Name", cartList.get(position).getName());
        intent.putExtra("Price", cartList.get(position).getPrice());
        intent.putExtra("Stock", cartList.get(position).getAvailableStock());
        intent.putExtra("Description", cartList.get(position).getDescription());
        intent.putExtra("Id", cartList.get(position).getGift_id());
        intent.putExtra("Type", cartList.get(position).getGiftType());

        startActivity(intent);
        overridePendingTransition(0, 0);
        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        finish();
    }

    private void removeGiftFromCart(GiftInCart gift, String loggedUserID) {
        DatabaseReference tableRef = FirebaseDatabase.getInstance().getReference("Cart" + loggedUserID);
        DatabaseReference cartIDRef = tableRef.child("gift_id");
        cartIDRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()) {
                    cartIDRef.child(gift.getGift_id()).removeValue();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

    }
    public void removeButtonClick(int position) {
        GiftInCart gift =
        cartList.remove(position);
        removeGiftFromCart(gift,loggedInUserID);
        cartRecyclerAdapter.notifyItemRemoved(position);
    }


}