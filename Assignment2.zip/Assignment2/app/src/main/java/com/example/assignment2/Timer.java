package com.example.assignment2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
// --------------------------------------------------------------------
// Assignment 2
// Written by: Viktor Kostadinov
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
// timer, small timer to simulate an server-side order procession
public class Timer extends AppCompatActivity {

    private static int DISPLAY_TIME = 10000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer);
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent homeIntent = new Intent(Timer.this, OrderSuccess.class);
                startActivity(homeIntent);
                finish();
            }
        }, DISPLAY_TIME);
    }
}