package com.example.assignment2;
// --------------------------------------------------------------------
// Assignment 2
// Written by: Viktor Kostadinov
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
// essentially the page where you can see the individual gift and its details, there are things missing that I would like to implement in the future, reviews are missing and the buy now button has not been done
// use add to cart to test out the checkout implementation...
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class GiftView extends AppCompatActivity {
    //FirebaseDatabase database;
    DatabaseReference cartDBRef;
    DatabaseReference favDBRef;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        getWindow().setStatusBarColor(ContextCompat.getColor(GiftView.this, R.color.black));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.giftview);
        String defaultStockValue = "1";
        EditText neededStockView = findViewById(R.id.desiredStock);
        neededStockView.setText(defaultStockValue);
        BottomNavigationView navigationMenu = findViewById(R.id.giftNavigationMenu);
        navigationMenu.getMenu().findItem(R.id.shop).setChecked(true);
        navigationMenu.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.shop:
                        Intent intent = new Intent(getApplicationContext(), ShopRecycler.class);
                        overridePendingTransition(0, 0);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        break;
                    case R.id.favorites:
                        Intent intent2 = new Intent(GiftView.this, FavoritesRecycler.class);
                        overridePendingTransition(0, 0);
                        intent2.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent2);
                        break;
                    case R.id.cart:
                        Intent intent3 = new Intent(GiftView.this, CartRecycler.class);
                        overridePendingTransition(0, 0);
                        intent3.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent3);
                        break;
                    case R.id.profile:
                        Intent intent4 = new Intent(GiftView.this, MyProfile.class);
                        overridePendingTransition(0, 0);
                        intent4.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent4);
                        break;


                }
                return true;
            }
        }); {

        }
        String name = getIntent().getStringExtra("Name");
        String price = getIntent().getStringExtra("Price");
        String image = String.valueOf(getIntent().getStringExtra("Image"));
        String stock = getIntent().getStringExtra("Stock");
        String description = getIntent().getStringExtra("Description");
        String id = getIntent().getStringExtra("Id");
        String type = getIntent().getStringExtra("Type");
        TextView nameView = findViewById(R.id.giftName);
        TextView priceView = findViewById(R.id.giftPrice);
        ImageView imageView = (ImageView) findViewById(R.id.giftImage);
        TextView stockView = findViewById(R.id.giftStock);
        TextView descriptionView = findViewById(R.id.descriptionView);
        nameView.setText(name);
        priceView.setText(price);
        priceView.append("$");
        Glide.with(this).load(image).into(imageView);
        stockView.setText(stock);
        stockView.append(" In Stock.");
        descriptionView.setText(description);
        Button addToCartButton = findViewById(R.id.addToCartButton);
        Button buyNowButton = findViewById(R.id.buynowButton);
        ImageView favStarButton = findViewById(R.id.favStarButton);
        TextView addToFavButton = findViewById(R.id.addToFavButton);
        String loggedInUserID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        cartDBRef = FirebaseDatabase.getInstance().getReference().child("Cart" + loggedInUserID);
        favDBRef = FirebaseDatabase.getInstance().getReference().child("Favorites" + loggedInUserID);
        //GiftInCart thisGift = new GiftInCart(id, name, description, type, image, price, neededStockView.getText().toString(), stock, totalPrice);
        Gift originalGift = new Gift(id, name, description, type, image, price, stock);
        addToCartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String totalPrice = Double.toString((Double.parseDouble(price)) * Double.parseDouble(neededStockView.getText().toString()));
                GiftInCart thisGift = new GiftInCart(id, name, description, type, image, price, neededStockView.getText().toString(), stock, totalPrice);
                insertGiftIntoCart(thisGift, loggedInUserID);
            }
        });
        buyNowButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        }); {

        }
        favStarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                insertGiftIntoFavorites(originalGift, loggedInUserID);
            }
        });
    }
    private void insertGiftIntoCart(GiftInCart gift, String loggedUserID) {
        DatabaseReference tableRef = FirebaseDatabase.getInstance().getReference("Cart" + loggedUserID);
        DatabaseReference giftIdRef = tableRef.child("gift_id");
        giftIdRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()) {
                    cartDBRef.child(gift.getGift_id()).setValue(gift);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

    }
    private void insertGiftIntoFavorites(Gift gift, String loggedUserID) {
        DatabaseReference tableRef = FirebaseDatabase.getInstance().getReference("Favorites" + loggedUserID);
        DatabaseReference giftIdRef = tableRef.child("gift_id");
        giftIdRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (!snapshot.exists()) {
                    favDBRef.child(gift.getGift_id()).setValue(gift);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

    }

}
