package com.example.assignment2;
// --------------------------------------------------------------------
// Assignment 2
// Written by: Viktor Kostadinov
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
// takes a note of gift in cart, basically same thing as gift class, but takes into account total price and the needed stock of the customer
public class GiftInCart {
    String gift_id;
    String name;
    String description;
    String giftType;
    String imageUrl;
    String price;
    String neededStock;
    String availableStock;
    String totalPrice;

    public GiftInCart () {

    }

    public GiftInCart(String gift_id, String name, String description, String giftType, String imageUrl, String price, String neededStock, String availableStock, String totalPrice) {
        this.gift_id = gift_id;
        this.name = name;
        this.description = description;
        this.giftType = giftType;
        this.imageUrl = imageUrl;
        this.price = price;
        this.neededStock = neededStock;
        this.availableStock = availableStock;
        this.totalPrice = totalPrice;
    }

    public String getGift_id() {
        return gift_id;
    }

    public void setGift_id(String gift_id) {
        this.gift_id = gift_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getGiftType() {
        return giftType;
    }

    public void setGiftType(String giftType) {
        this.giftType = giftType;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getNeededStock() {
        return neededStock;
    }

    public void setNeededStock(String neededStock) {
        this.neededStock = neededStock;
    }

    public String getAvailableStock() {
        return availableStock;
    }

    public void setAvailableStock(String availableStock) {
        this.availableStock = availableStock;
    }

    public String getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(String totalPrice) {
        this.totalPrice = totalPrice;
    }

    @Override
    public String toString() {
        return "GiftInCart{" +
                "gift_id='" + gift_id + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", giftType='" + giftType + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", price='" + price + '\'' +
                ", neededStock='" + neededStock + '\'' +
                ", availableStock='" + availableStock + '\'' +
                ", totalPrice='" + totalPrice + '\'' +
                '}';
    }
}
