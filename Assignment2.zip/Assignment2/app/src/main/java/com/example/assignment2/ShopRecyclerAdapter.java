package com.example.assignment2;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
// --------------------------------------------------------------------
// Assignment 2
// Written by: Viktor Kostadinov
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
// recycler adapter for shop
public class ShopRecyclerAdapter extends RecyclerView.Adapter<ShopRecyclerAdapter.ViewHolder> {

   private final ListenerInterface listener;
   Context giftContext;
   ArrayList<Gift> giftList;



    public ShopRecyclerAdapter(Context giftContext, ArrayList<Gift> giftList, ListenerInterface listener) {
        this.giftContext = giftContext;
        this.giftList = giftList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ShopRecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.shopview, parent, false);
        return new ViewHolder(view, listener);
    }

    @Override
    public void onBindViewHolder(@NonNull ShopRecyclerAdapter.ViewHolder holder, int position) {
        Gift gift = giftList.get(position);
        holder.giftName.setText(String.valueOf(gift.getName()));
        holder.giftPrice.setText(String.valueOf(gift.getPrice()));
        holder.giftType.setText(String.valueOf(gift.getGiftType()));
        holder.giftPrice.append("$");
        Glide.with(giftContext).load(gift.getImageUrl()).into(holder.giftImage);

    }

    @Override
    public int getItemCount() {
        return giftList.size();
    }

    public void filterGiftNameList(ArrayList<Gift> filteredGiftNameList) {
        giftList = filteredGiftNameList;
        notifyDataSetChanged();
    }
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView giftName;
        TextView giftPrice;
        ImageView giftImage;
        TextView giftType;
        public ViewHolder(@NonNull View itemView, ListenerInterface listener) {
            super(itemView);
            giftImage = itemView.findViewById(R.id.imageListView);
            giftName = itemView.findViewById(R.id.giftName);
            giftPrice = itemView.findViewById(R.id.giftPrice);
            giftType = itemView.findViewById(R.id.giftTypeView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}