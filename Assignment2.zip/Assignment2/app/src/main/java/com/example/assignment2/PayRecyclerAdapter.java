package com.example.assignment2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
// --------------------------------------------------------------------
// Assignment 2
// Written by: Viktor Kostadinov
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
// recycler adapter for pay page
public class PayRecyclerAdapter extends RecyclerView.Adapter<PayRecyclerAdapter.ViewHolder> {

    Context cartContext;
    ArrayList<GiftInCart> cartList;

    public PayRecyclerAdapter(Context giftContext, ArrayList<GiftInCart> cartList) {
        this.cartContext = giftContext;
        this.cartList = cartList;
    }

    @NonNull
    @Override
    public PayRecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.payselectionview, parent, false);
        return new PayRecyclerAdapter.ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull PayRecyclerAdapter.ViewHolder holder, int position) {
        GiftInCart gift = cartList.get(position);
        gift.setNeededStock(gift.getNeededStock());
        //gift.setTotalPrice(Double.toString((Double.parseDouble(gift.getPrice())) * Double.parseDouble(gift.getNeededStock())));
        holder.giftName.setText(String.valueOf(gift.getName()));
        //  holder.giftPrice.setText(String.valueOf(gift.getPrice()));
        holder.giftPrice.setText(String.valueOf(gift.getTotalPrice()));
        holder.giftNeededStock.setText(String.valueOf(gift.getNeededStock()));
        holder.giftPrice.append("$");
        Glide.with(cartContext).load(gift.getImageUrl()).into(holder.giftImage);
        String loggedInUserID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        //gift.setNeededStock("2");
        //insertGiftIntoCart(gift, loggedInUserID);




    }



    @Override
    public int getItemCount() {
        return cartList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView giftName;
        TextView giftPrice;
        ImageView giftImage;
        TextView giftNeededStock;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            giftImage = itemView.findViewById(R.id.payImageListView);
            giftName = itemView.findViewById(R.id.payGiftName);
            giftPrice = itemView.findViewById(R.id.payGiftPrice);
            giftNeededStock = itemView.findViewById(R.id.payGiftQuantity);

        }
    }
}