package com.example.assignment2;
// --------------------------------------------------------------------
// Assignment 2
// Written by: Viktor Kostadinov
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
// helps getting recyclerview item and being able to click on each item to go through another page
public interface ListenerInterface {
    void onItemClick(int position);
}
