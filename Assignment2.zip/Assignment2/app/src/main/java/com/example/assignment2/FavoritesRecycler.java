package com.example.assignment2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.widget.EditText;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
// --------------------------------------------------------------------
// Assignment 2
// Written by: Viktor Kostadinov
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
// recycler for favorite list, it works more or less satisfyingly, wanted to implement remove button to remove gift from favorites for fun but will be completed some other time...
public class FavoritesRecycler extends AppCompatActivity implements ListenerInterface {

    RecyclerView recyclerView;
    private DatabaseReference database;
    private ArrayList<Gift> favoriteList;
    private FavoritesRecyclerAdapter favoriteRecyclerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.favorites);
        getSupportActionBar().hide();
        BottomNavigationView navigationMenu = findViewById(R.id.favoriteNavigationMenu);
        navigationMenu.getMenu().findItem(R.id.favorites).setChecked(true);
        navigationMenu.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.cart:
                        Intent intent = new Intent(FavoritesRecycler.this, CartRecycler.class);
                        overridePendingTransition(0, 0);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        break;
                    case R.id.favorites:
                        intent = new Intent(FavoritesRecycler.this, FavoritesRecycler.class);
                        overridePendingTransition(0, 0);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        break;
                    case R.id.shop:
                        intent = new Intent(FavoritesRecycler.this, ShopRecycler.class);
                        overridePendingTransition(0, 0);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        break;
                    case R.id.profile:
                        intent = new Intent(FavoritesRecycler.this, MyProfile.class);
                        overridePendingTransition(0, 0);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        break;



                }
                return true;
            }
        }); {

        }
        recyclerView = findViewById(R.id.favoritegifts);
        String loggedInUserID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        database = FirebaseDatabase.getInstance().getReference("Favorites" + loggedInUserID);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        favoriteList = new ArrayList<>();
        favoriteRecyclerAdapter = new FavoritesRecyclerAdapter(this, favoriteList, this);
        recyclerView.setAdapter(favoriteRecyclerAdapter);
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Gift gift = dataSnapshot.getValue(Gift.class);
                    favoriteList.add(gift);

                }
                favoriteRecyclerAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        EditText searchBar = findViewById(R.id.favoriteSearchBar);
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                filterGiftName(editable.toString());
            }
        });



    }

    private void filterGiftName(String searchTitle) {
        ArrayList<Gift> giftNamesList = new ArrayList<>();
        for (Gift gift : favoriteList) {
            if (gift.getName().toLowerCase().contains(searchTitle.toLowerCase())) {
                giftNamesList.add(gift);
            }
            else if (gift.getGiftType().equalsIgnoreCase(searchTitle)) {
                giftNamesList.add(gift);
            }
        }
        favoriteRecyclerAdapter.filterGiftNameList(giftNamesList);
    }



    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(FavoritesRecycler.this, GiftView.class);
        intent.putExtra("Image", favoriteList.get(position).getImageUrl());
        intent.putExtra("Name", favoriteList.get(position).getName());
        intent.putExtra("Price", favoriteList.get(position).getPrice());
        intent.putExtra("Stock", favoriteList.get(position).getStock());
        intent.putExtra("Description", favoriteList.get(position).getDescription());
        intent.putExtra("Id", favoriteList.get(position).getGift_id());
        intent.putExtra("Type", favoriteList.get(position).getGiftType());
        startActivity(intent);
        overridePendingTransition(0, 0);
        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        finish();
    }


}