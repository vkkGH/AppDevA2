package com.example.assignment2;
// --------------------------------------------------------------------
// Assignment 2
// Written by: Viktor Kostadinov
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
// gift class, please take note that flowers and gift are considered both as a gift, and their types are specified by giftType...
public class Gift {
    String gift_id;
    String name;
    String description;
    String giftType;
    String imageUrl;
    String price;
    String stock;

    public Gift() {

    }

    public Gift(String gift_id, String name, String description, String giftType, String imageUrl, String price, String stock) {
        this.gift_id = gift_id;
        this.name = name;
        this.description = description;
        this.giftType = giftType;
        this.imageUrl = imageUrl;
        this.price = price;
        this.stock = stock;
    }


    public String getGift_id() {
        return gift_id;
    }

    public void setGift_id(String gift_id) {
        this.gift_id = gift_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getGiftType() {
        return giftType;
    }

    public void setGiftType(String giftType) {
        this.giftType = giftType;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    @Override
    public String toString() {
        return "Gift{" +
                "gift_id='" + gift_id + '\'' +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", giftType='" + giftType + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", price='" + price + '\'' +
                ", stock='" + stock + '\'' +
                '}';
    }
}
