package com.example.assignment2;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;
// --------------------------------------------------------------------
// Assignment 2
// Written by: Viktor Kostadinov
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
// recycler adapter for favorite list
public class FavoritesRecyclerAdapter extends RecyclerView.Adapter<FavoritesRecyclerAdapter.ViewHolder>  {

    private final ListenerInterface listener;
    Context favContext;
    ArrayList<Gift> favoritesList;

    public FavoritesRecyclerAdapter(Context favContext, ArrayList<Gift> favoritesList, ListenerInterface listener) {
        this.favContext = favContext;
        this.favoritesList = favoritesList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public FavoritesRecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.favoritesview, parent, false);
        return new FavoritesRecyclerAdapter.ViewHolder(view, listener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Gift gift = favoritesList.get(position);
        holder.giftName.setText(String.valueOf(gift.getName()));
        holder.giftPrice.setText(String.valueOf(gift.getPrice()));
        holder.giftType.setText(String.valueOf(gift.getGiftType()));
        holder.giftPrice.append("$");
        Glide.with(favContext).load(gift.getImageUrl()).into(holder.giftImage);
    }


    @Override
    public int getItemCount() {
        return favoritesList.size();
    }

    public void filterGiftNameList(ArrayList<Gift> filteredGiftNameList) {
        favoritesList = filteredGiftNameList;
        notifyDataSetChanged();
    }



    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView giftName;
        TextView giftPrice;
        ImageView giftImage;
        TextView giftType;
        public ViewHolder(@NonNull View itemView, ListenerInterface listener) {
            super(itemView);
            giftImage = itemView.findViewById(R.id.favoriteImageListView);
            giftName = itemView.findViewById(R.id.favoriteGiftName);
            giftPrice = itemView.findViewById(R.id.favoriteGiftPrice);
            giftType = itemView.findViewById(R.id.favoriteGiftType);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (listener != null) {
                        int position = getAdapterPosition();
                        if (position != RecyclerView.NO_POSITION) {
                            listener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }
}