package com.example.assignment2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
// --------------------------------------------------------------------
// Assignment 2
// Written by: Viktor Kostadinov
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
// register function, uses firebase authentication and firebase firestore
public class Register extends AppCompatActivity {
    FirebaseAuth fAuth;
    FirebaseFirestore fStore;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        fAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();
        ImageButton backButton = findViewById(R.id.backButton);
        Button registerButton = findViewById(R.id.loginButton);
        EditText emailInfo = findViewById(R.id.registerEmail);
        EditText firstNameInfo = findViewById(R.id.registerFName);
        EditText lastNameInfo = findViewById(R.id.registerLName);
        EditText phoneInfo = findViewById(R.id.registerPhone);
        EditText passwordInfo = findViewById(R.id.registerPassword);
        EditText confirmPasswordInfo = findViewById(R.id.registerConfirmPassword);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Register.this, Login.class);
                overridePendingTransition(0, 0);
                intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
            }
        });
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast message = null;
                String email = emailInfo.getText().toString();
                String firstName = firstNameInfo.getText().toString();
                String lastName = lastNameInfo.getText().toString();
                String phone = phoneInfo.getText().toString();
                String password = passwordInfo.getText().toString();
                String confirmPassword = confirmPasswordInfo.getText().toString();

                //fAuth = FirebaseAuth.getInstance();
                if (firstName.isEmpty() || lastName.isEmpty() || phone.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {

                    message = Toast.makeText(getApplicationContext(), "Please fill all the fields!", Toast.LENGTH_LONG);
                    message.show();
                }
                if (!firstName.isEmpty() && !lastName.isEmpty() && !phone.isEmpty() && !email.isEmpty() && !password.isEmpty() && !confirmPassword.isEmpty() && password.length() < 6) {
                    if (message != null) {
                        message.cancel();
                    }
                    message = Toast.makeText(getApplicationContext(), "Your password has to contain at least 6 characters!", Toast.LENGTH_LONG);
                    message.show();
                }
                if (!password.equals(confirmPassword)) {
                    if (message != null) {
                        message.cancel();
                    }
                    message = Toast.makeText(getApplicationContext(), "Your passwords do not match!", Toast.LENGTH_LONG);
                    message.show();
                }
                if (!firstName.isEmpty() && !lastName.isEmpty() && !phone.isEmpty() && !email.isEmpty() && !password.isEmpty() && !confirmPassword.isEmpty()
                        && (password.equals(confirmPassword)) && password.length() >= 6) {
                    fAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {

                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                String userID = fAuth.getCurrentUser().getUid();
                                DocumentReference reference  = fStore.collection("Users").document(userID);
                                Map<String, Object> user = new HashMap<>();
                                user.put("First Name", firstName);
                                user.put("Last Name", lastName);
                                user.put("Email", email);
                                user.put("Phone", phone);
                                reference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void unused) {
                                        Intent intent = new Intent(getApplicationContext(), Login.class);
                                        startActivity(intent);
                                    }
                                });
                            }
                        }
                    });

                    if (message != null) {
                        message.cancel();
                    }
                    message = Toast.makeText(getApplicationContext(), "You have registered successfully!", Toast.LENGTH_LONG);
                    message.show();
                    message = Toast.makeText(getApplicationContext(), "Please login to continue!", Toast.LENGTH_LONG);
                    message.show();


                }

            }


        });
            }

    }
