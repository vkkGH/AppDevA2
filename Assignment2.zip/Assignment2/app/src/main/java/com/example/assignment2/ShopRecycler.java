package com.example.assignment2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Locale;
// --------------------------------------------------------------------
// Assignment 2
// Written by: Viktor Kostadinov
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
// recycler for shop, here all the gifts (gifts & flowers) are to be displayed in a list
public class ShopRecycler extends AppCompatActivity implements ListenerInterface {
    RecyclerView recyclerView;
    private DatabaseReference database;
    private ArrayList<Gift> giftList;
    private ShopRecyclerAdapter shopRecyclerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.shop);
        getSupportActionBar().hide();
        BottomNavigationView navigationMenu = findViewById(R.id.navigationMenu);
        navigationMenu.getMenu().findItem(R.id.shop).setChecked(true);
        navigationMenu.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.cart:
                        Intent intent = new Intent(ShopRecycler.this, CartRecycler.class);
                        overridePendingTransition(0, 0);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        break;
                    case R.id.favorites:
                        intent = new Intent(ShopRecycler.this, FavoritesRecycler.class);
                        overridePendingTransition(0, 0);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        break;
                    case R.id.profile:
                        intent = new Intent(ShopRecycler.this, MyProfile.class);
                        overridePendingTransition(0, 0);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                        startActivity(intent);
                        break;



                }
                return true;
            }
        }); {

        }
        recyclerView = findViewById(R.id.gifts);
        database = FirebaseDatabase.getInstance().getReference("Gift");
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        giftList = new ArrayList<>();
        shopRecyclerAdapter = new ShopRecyclerAdapter(this, giftList, this);
        recyclerView.setAdapter(shopRecyclerAdapter);
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Gift gift = dataSnapshot.getValue(Gift.class);
                    giftList.add(gift);

                }
                shopRecyclerAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        EditText searchBar = findViewById(R.id.searchBar);
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                filterGiftName(editable.toString());
            }
        });
        TextView discoverMapView = findViewById(R.id.discoverMapView);
        discoverMapView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String link = "https://www.google.com/maps/place/10475+S+De+Anza+Blvd,+Cupertino,+CA+95014,+USA/@37.3168882,-122.0335398,20z/";
                Uri uri = Uri.parse(link);
                startActivity(new Intent(Intent.ACTION_VIEW, uri));
            }
        });
    }
private void filterGiftName(String searchTitle) {
        ArrayList<Gift> giftNamesList = new ArrayList<>();
        for (Gift gift : giftList) {
            if (gift.getName().toLowerCase().contains(searchTitle.toLowerCase())) {
                giftNamesList.add(gift);
            }
            else if (gift.getGiftType().equalsIgnoreCase(searchTitle)) {
                giftNamesList.add(gift);
            }
        }
        shopRecyclerAdapter.filterGiftNameList(giftNamesList);
}

    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(ShopRecycler.this, GiftView.class);
        intent.putExtra("Image", giftList.get(position).getImageUrl());
        intent.putExtra("Name", giftList.get(position).getName());
        intent.putExtra("Price", giftList.get(position).getPrice());
        intent.putExtra("Stock", giftList.get(position).getStock());
        intent.putExtra("Description", giftList.get(position).getDescription());
        intent.putExtra("Id", giftList.get(position).getGift_id());
        intent.putExtra("Type", giftList.get(position).getGiftType());
        startActivity(intent);
        overridePendingTransition(0, 0);
        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        finish();
    }

}