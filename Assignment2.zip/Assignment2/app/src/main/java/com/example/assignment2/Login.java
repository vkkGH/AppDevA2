package com.example.assignment2;
// --------------------------------------------------------------------
// Assignment 2
// Written by: Viktor Kostadinov
// For Application Development 2 (Mobile) - Winter 2022
// --------------------------------------------------------------------
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
// login page, uses firebase firestore and firebase authentication...

public class Login extends AppCompatActivity {
    FirebaseAuth fAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        fAuth = FirebaseAuth.getInstance();
        EditText emailInfo = findViewById(R.id.loginEmail);
        EditText passwordInfo = findViewById(R.id.loginPassword);
        TextView resetPassword = findViewById(R.id.forgotPassword);
        resetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login.this, ForgotPassword.class);
                overridePendingTransition(0, 0);
                intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
            }
        });
        TextView registerOption = (TextView) findViewById(R.id.registerView);
        Button loginButton = findViewById(R.id.loginButton);
        registerOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login.this, Register.class);
                overridePendingTransition(0, 0);
                intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);
            }
        });
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast message = null;
                String email = emailInfo.getText().toString();
                String password = passwordInfo.getText().toString();
                if (email.isEmpty() || password.isEmpty()) {

                    message = Toast.makeText(getApplicationContext(), "Please fill all the fields!", Toast.LENGTH_LONG);
                    message.show();
                }
                else {
                    fAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(getApplicationContext(), "You have logged in successfully!", Toast.LENGTH_LONG).show();
                                Intent intent = new Intent(getApplicationContext(), ShopRecycler.class);
                                startActivity(intent);
                            }
                            else {
                                Toast.makeText(getApplicationContext(), "Login unsuccessful!", Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }

            }
        });
         {

        }
    }
}